import Foundation
import SwiftUI
import Darwin

@MainActor
final class StatusMonitor: ObservableObject {
    @Published private(set) var cpuUsage = 0
    @Published private(set) var memoryText = "— MB"
    @Published private(set) var uptimeText = "0m"
    @Published private(set) var networkText = "Idle"
    @Published private(set) var latencyText = "—"
    @Published private(set) var lastResult = "Enter a host and run a check."
    @Published private(set) var isChecking = false

    private var timer: Timer?
    private let startedAt = Date()

    func start() {
        refreshMetrics()
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.refreshMetrics() }
        }
    }

    private func refreshMetrics() {
        let elapsed = Int(Date().timeIntervalSince(startedAt))
        let hours = elapsed / 3600
        let minutes = (elapsed % 3600) / 60
        uptimeText = hours > 0 ? "\(hours)h \(minutes)m" : "\(minutes)m"

        var info = mach_task_basic_info()
        var count = mach_msg_type_number_t(
            MemoryLayout<mach_task_basic_info>.size / MemoryLayout<natural_t>.size
        )
        let result = withUnsafeMutablePointer(to: &info) { ptr in
            ptr.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
            }
        }
        if result == KERN_SUCCESS {
            let mb = Double(info.resident_size) / 1_048_576
            memoryText = String(format: "%.0f MB", mb)
        }

        // Approximate CPU time consumed by this process since launch.
        var usage = task_thread_times_info()
        var usageCount = mach_msg_type_number_t(
            MemoryLayout<task_thread_times_info>.size / MemoryLayout<integer_t>.size
        )
        let cpuResult = withUnsafeMutablePointer(to: &usage) { ptr in
            ptr.withMemoryRebound(to: integer_t.self, capacity: Int(usageCount)) {
                task_info(mach_task_self_, task_flavor_t(TASK_THREAD_TIMES_INFO), $0, &usageCount)
            }
        }
        if cpuResult == KERN_SUCCESS {
            let user = Double(usage.user_time.seconds) + Double(usage.user_time.microseconds) / 1_000_000
            let system = Double(usage.system_time.seconds) + Double(usage.system_time.microseconds) / 1_000_000
            let runtime = max(Date().timeIntervalSince(startedAt), 1)
            cpuUsage = min(100, max(0, Int(((user + system) / runtime * 100).rounded())))
        }
    }

    func checkLatency(host: String) async {
        let target = host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !target.isEmpty,
              target.rangeOfCharacter(from: CharacterSet(charactersIn: " /?#")) == nil else {
            lastResult = "Enter a valid hostname or IP address."
            return
        }

        isChecking = true
        networkText = "Checking"
        defer { isChecking = false }

        guard let url = URL(string: "https://\(target)/") else {
            networkText = "Invalid"
            lastResult = "Invalid hostname."
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "HEAD"
        request.timeoutInterval = 5
        request.cachePolicy = .reloadIgnoringLocalCacheData

        let start = ContinuousClock.now
        do {
            let (_, response) = try await URLSession.shared.data(for: request)
            let duration = start.duration(to: .now)
            let components = duration.components
            let ms = Double(components.seconds) * 1000 +
                     Double(components.attoseconds) / 1e15
            latencyText = String(format: "%.0f", ms)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            networkText = "Online"
            lastResult = "HTTPS response from \(target) (HTTP \(status)). This measures HTTPS response time, not ICMP ping."
        } catch {
            latencyText = "—"
            networkText = "Unavailable"
            lastResult = "Could not reach \(target): \(error.localizedDescription)"
        }
    }

    deinit {
        timer?.invalidate()
    }
}

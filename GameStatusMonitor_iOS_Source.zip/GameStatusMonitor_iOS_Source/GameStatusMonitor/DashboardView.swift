import SwiftUI

struct DashboardView: View {
    @StateObject private var monitor = StatusMonitor()
    @State private var host = "1.1.1.1"

    private let columns = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("GAME STATUS")
                                .font(.system(size: 12, weight: .bold, design: .rounded))
                                .tracking(2)
                                .foregroundStyle(.cyan)
                            Text("Device dashboard")
                                .font(.title2.bold())
                        }
                        Spacer()
                        Circle()
                            .fill(monitor.isChecking ? .orange : .green)
                            .frame(width: 10, height: 10)
                        Text(monitor.isChecking ? "Checking" : "Ready")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                    .padding(.top, 8)

                    LazyVGrid(columns: columns, spacing: 12) {
                        MetricCard(title: "CPU", value: "\(monitor.cpuUsage)%*", subtitle: "App process", symbol: "cpu")
                        MetricCard(title: "MEMORY", value: monitor.memoryText, subtitle: "App process", symbol: "memorychip")
                        MetricCard(title: "UPTIME", value: monitor.uptimeText, subtitle: "Since launch", symbol: "clock")
                        MetricCard(title: "NETWORK", value: monitor.networkText, subtitle: "Reachability check", symbol: "wifi")
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("PING CHECK")
                            .font(.caption.bold())
                            .tracking(1.5)
                            .foregroundStyle(.cyan)

                        HStack {
                            Image(systemName: "network")
                                .foregroundStyle(.secondary)
                            TextField("Host or IP (e.g. 1.1.1.1)", text: $host)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .keyboardType(.URL)
                        }
                        .padding(12)
                        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12))

                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            Text(monitor.latencyText)
                                .font(.system(size: 34, weight: .bold, design: .rounded))
                            Text("ms")
                                .foregroundStyle(.secondary)
                            Spacer()
                            Button {
                                Task { await monitor.checkLatency(host: host) }
                            } label: {
                                Label("Check", systemImage: "arrow.clockwise")
                                    .font(.subheadline.bold())
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.cyan)
                        }
                        Text(monitor.lastResult)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(16)
                    .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 18))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.08)))

                    VStack(alignment: .leading, spacing: 8) {
                        Label("iOS limitations", systemImage: "info.circle")
                            .font(.headline)
                        Text("iOS does not expose a universal API for live game FPS, device temperature, or whole-device CPU usage to ordinary apps. This dashboard reports app-process metrics and network latency only; it does not inject into or read another game's memory.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(16)
                    .background(Color.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 18))

                    Text("*CPU is an approximate app-process measurement; background execution and OS scheduling can affect readings.")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(18)
            }
            .background(
                LinearGradient(colors: [Color(red: 0.04, green: 0.07, blue: 0.13), .black],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            )
            .toolbar(.hidden, for: .navigationBar)
            .task { monitor.start() }
        }
    }
}

private struct MetricCard: View {
    let title: String
    let value: String
    let subtitle: String
    let symbol: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: symbol)
                    .foregroundStyle(.cyan)
                Spacer()
                Text(title)
                    .font(.caption2.bold())
                    .tracking(1)
                    .foregroundStyle(.secondary)
            }
            Text(value)
                .font(.system(size: 25, weight: .bold, design: .rounded))
                .lineLimit(1)
                .minimumScaleFactor(0.75)
            Text(subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(15)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 17))
        .overlay(RoundedRectangle(cornerRadius: 17).stroke(Color.white.opacity(0.08)))
    }
}

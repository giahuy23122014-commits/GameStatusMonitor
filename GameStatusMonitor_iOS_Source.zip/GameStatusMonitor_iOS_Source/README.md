# Game Status Monitor (iOS)

A SwiftUI iOS dashboard showing app-process memory, an approximate app CPU metric, uptime, and HTTPS response time for a user-supplied host.

## Important limitations
- Ordinary iOS apps cannot universally read another game's live FPS, whole-device temperature, or whole-device CPU usage.
- The latency checker uses HTTPS HEAD requests. It is **not ICMP ping** and reports HTTPS response time, which includes server/network behavior.
- This app does not inject into games or inspect another app's memory.
- This is an Xcode source project starter, not a prebuilt/signed IPA.

## Build
1. On a Mac, install a current version of Xcode.
2. Create a new iOS **App** project named `GameStatusMonitor`, using **Swift** and **SwiftUI**.
3. Set deployment target to iOS 16 or later.
4. Replace the generated app source with the three `.swift` files in `GameStatusMonitor/`.
5. In the project target's **Signing & Capabilities**, select your Apple development team and set a unique bundle identifier.
6. Select an iPhone simulator or connected iPhone and press Run.
7. To export an IPA, use Xcode's Archive/Distribute workflow with an appropriate signing method, or use a compatible signing workflow after building the app.

## Files
- `GameStatusMonitorApp.swift` — app entry point
- `DashboardView.swift` — dashboard UI
- `StatusMonitor.swift` — app-process metrics and HTTPS response-time check
